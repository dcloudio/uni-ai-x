# 七牛应用能力接入与实测

核对对象：[DeepSeek 发布全家桶应用 API](https://mp.weixin.qq.com/s/78KBHc4-4N5b2vfL9SkutQ)。
测试日期：2026-11-16。以下结论仅针对本次账号、临时 Token、接口路径和模型的实际结果，不代表七牛所有产品都不支持某项能力。

## 已接入

选择模型 **DeepSeek Flash · 七牛**（`deepseek/deepseek-v4.1-flash`）。原默认提供商配置保留。沿用 UniCloud 获取七牛临时 Token 的机制，不在前端放长期密钥。

| 能力 | 实现与使用 | 实测 |
| --- | --- | --- |
| 阅读链接 / Fetch | 模型调用 `read_web_link`，应用请求 `/v1/tools/fetch`，结果回传模型 | 成功读取上述公众号正文并生成摘要；失败时明确报告工具错误 |
| 联网搜索 / Search | 打开“联网搜索”，模型调用 `search_web`，应用请求 `/v1/tools/search` | 实际返回来源，回答展示引用 |
| 思考模式下搜索 | 同时打开思考和联网搜索，最多五轮模型请求，可反复搜索和阅读链接 | 实际搜索并生成带引用回答；多轮来源去重和编号通过自动化测试 |
| 图片识别 | 复用现有图片上传入口，启用该模型的图片输入能力 | 实际识别合成图片上的唯一编号和数量 |
| ASR / 语音输入 | 点“语音”开始、点“结束”停止；识别文字追加到输入框，由用户编辑发送 | `/v1/audio/transcriptions`、`qwen/qwen-audio-3.0-asr-flash` 实际返回文字；浏览器合成音频流完成录音、WAV 转换、上传及输入框回填 |

搜索和阅读采用应用端 Function Calling 编排，并未证明七牛原样支持官方内置 `deepseek_web_search` / `deepseek_read_url`。目前只有网页搜索，未实现图片搜索；最多五轮的编排也不等同于 DeepSeek 官方服务端完整搜索策略。

图片识别走模型图片输入，不等同于独立 OCR 或 PDF/Office 文档解析。

## 尚未接入：实测阻塞

| 能力 | 实测结果 | 当前处理 |
| --- | --- | --- |
| PDF / Office 文件输入 | 文档描述的 `type:pdf` 被拒绝；改用 `type:file` 的 URL、内嵌 PDF 数据仍返回 HTTP 400；`/v1/files` 上传也返回 HTTP 400 | 不开放文档上传入口；需要可工作的协议或另接解析服务 |
| 独立 OCR | `/v1/tools/ocr` 按 `purpose=text_recognition`、文件顺序上传 PNG，返回 HTTP 404 | 不开放；需要另一个已验证的 OCR 接口 |
| TTS | `/v1/tools/tts` 返回 HTTP 404 | 不开放；可另选语音合成模型，但尚未实施或验证 |
| 模型安全 | 合法 `safety_check.level=high` 和官方规定应拒绝的非法值均返回 HTTP 200，没有证据证明参数生效 | 不声称审核已开启，需要独立可验证的审核接口或厂商确认 |

知识库问答不在文章列出的直接能力中。本次未实现文档入库、向量检索和 RAG。

## 后续补充：通过项目已有 DeepSeek 官方线路接入

以上七牛接口的限制仍然存在。项目同时配置了 DeepSeek 官方直连，因此新增以下能力走 **DeepSeek Flash**（`deepseek` 提供商、`deepseek-flash`），不是“DeepSeek Flash · 七牛”。未改动提供商配置文件；沿用现有 `getToken`，没有新增硬编码凭证，也没有把官方凭证改为 UniCloud 代理。

| 能力 | 使用方式 | 已完成的验证 |
| --- | --- | --- |
| PDF / Office / 文本文件输入 | 输入栏“文件”→“添加文档用于问答”，解析完成后发送问题 | DOCX、PDF 均完成实际上传、解析及问答；PDF 追问无需重传，37 + 5 回答 42；刷新后保留文件 ID。Excel、PowerPoint 等其他格式按官方协议分配 purpose，未逐一实测 |
| 独立 OCR | “文件”→“识别文字到输入框” | 实际上传 PNG 到 `/v1/tools/ocr`，正确回填 `OCR IRIS-96274 COUNT 83`；空页面、解析不完整按失败处理 |
| TTS | 回答下方“朗读”，再次点击可停止或取消 | `/v1/tools/tts` 返回 WAV，播放器进入播放状态并结束；限定官方计费字符上限；停止时取消请求、销毁播放器、清理临时音频 |
| 模型安全 | 官方 Flash 对话默认带 `safety_check.level=high` | 合法参数成功、非法值返回 400；实际风险提问得到拒答。另用模拟 SSE 在完整应用链路验证：先显示的回答和思考在 `content_filter` 到达后全部撤下，只显示拒答提示 |
| 以图搜索 | 官方 Flash 开启“联网搜索”，附图片并要求查找图片来源 | 实际出现 `kind=image_search`，12 条来源含图片 URL；来源面板支持图片预览。目标图片不可访问时明确报错，不宣称搜索完成 |
| 官方服务端搜索与阅读 | 官方 Flash 开启搜索，或直接发送链接 | 官方原生 `deepseek_web_search` / `deepseek_read_url`；保留 `server_tool_calls`、网页签名和来源供追问使用，不占用应用端五轮工具循环 |

文件附件会随消息持久化；编辑消息时保留附件，改用不支持文件的模型会明确提示。每个待发送附件最多 32 MiB、最多 20 个；最终限制仍以官方接口对整段历史的校验为准。移除待发送附件仅取消本地引用，不删除服务器已解析的文件。

本轮新增 6 项能力测试，加上原有回归及存储测试，共 **27 项通过**。Web 功能与桌面、手机尺寸截图已检查。Android 真机（192.168.2.3:42999）通过 Word/PDF 系统选取、上传、问答、图片 OCR 回填、官方链接阅读、以图搜索与来源面板检查。原生录音和播放仍待新基座完成验证，详见下文。官方安全参数不保证拦截所有风险，真实拒答样例也不能单独证明拒答由安全参数而非模型本身触发。

## 验证范围

- 18 项自动化测试通过，覆盖读取成功/失败、参数校验、取消请求与迟到流、模型工具回路、多轮搜索、来源编号、语音上传、WAV 编码、原有日历调用。
- HBuilderX Web 开发服务器已运行，复用 localhost:5173，执行 `cli logcat web --project /Users/json/Desktop/code/uni-ai-x --browser Chrome --mode lastBuild` 核对最新日志。
- Web 热更新期间出现过框架错误；冷刷新后另行检查。既有代码高亮及嵌套类型编译警告不属于本次新增代码。
- Web ASR 使用合成语音测试。Android 旧自定义基座缺少 `uni-recorder`、`uni-createInnerAudioContext`；TTS 已实际返回 HTTP 200、保存 1,167,404 字节 WAV，但创建播放器提示模块不存在，尚不能标记播放通过。已提交包含两个模块的新基座云打包，等待结果。iOS 未实机验证。

复现自动化验证：

```sh
node --test tests/web-reader.test.mjs tests/agent-web-search.test.mjs tests/web-search-request.test.mjs tests/agent-tools-stream.test.mjs tests/calendar-call.test.mjs tests/speech-input.test.mjs tests/search-citation-links.test.mjs
```

## Android 真机补充

- 修复旧消息没有 `file_list` 时，原生 Vapor 对 undefined 执行列表渲染产生 `.map` 异常；文件列表统一默认空数组。
- 官方适配器改为显式安装，在应用启动和发起请求前注册；修复原生仅依赖副作用导入时未启用阅读工具的问题。修复后先复测 Web，再在 Android 确认 example.com 标题及来源。
- Word 实际读出 `IRIS-96274 / 83`，PDF 实际读出 `ORCHID-731926 / 37`，OCR 正确回填编号和数量。
- 以图搜索实际返回 12 条来源；真机来源面板正常展示图片，不可访问图片显示“图片暂不可用”；点击来源可打开网页。
- 临时 `[tts-probe]` 排查日志已移除；云构建编译通过，模块扫描确认包含录音和音频播放。
- 新基座打包 ticket：`1ac28fe0-e1c7-11f1-b4f9-a19bcfd0d3d4`。当前等待云端排队，未把排队或编译通过当成录音/播放成功。

截图证据保存在 `/private/tmp/uni-ai-android-pdf-result.png`、`/private/tmp/uni-ai-android-read-retry.png`、`/private/tmp/uni-ai-android-image-top.png`、`/private/tmp/uni-ai-android-source-return.png`。

## 追加补测（22:32）

- Android 官方纯文字联网搜索通过：搜索 Python 发布信息，返回 11 条来源；截图检查回答、来源列表和工具栏。该测试证明搜索链路，不保证模型对搜索结果的判断准确。
- Android 官方思考模式 + 搜索通过：比较 Python 版本，请求完成并返回 12 条来源；思考区展开/收起正常，回答和引用排版正常。
- 新增 XLSX、PPTX、TXT 唯一编号样本，三者首次真实上传均返回有效文件 ID；Web 界面再次上传 XLSX 返回 HTTP 402。官方余额接口返回 `is_available=false`，因此三种格式的问答及安卓界面流程尚未完成，不标记为通过。
- 22:31 查询新基座仍在云端排队，第 47 位，预计约 8 分钟进入打包。尚未安装新基座。

- Android 七牛组合测试通过：思考模式下同轮调用 `read_web_link`、`search_web`，日志确认模型两轮 HTTP 200；回答正确包含 Example Domain、python.org 及 5 条来源，截图检查正常。模型未返回 tool call ID 时走既有补全 ID 兼容处理，不影响完成。

- Android 七牛独立图片理解通过：关闭搜索、思考，实际选择文字图片并上传，模型精确回答 `IRIS-96274, 83`；截图检查正常。
- 22:36 查询新基座仍排队，第 22 位，预计约 3 分钟进入打包（不是打包完成时间）。
- 本轮仅补测并更新验证记录；未新增业务代码。Web 文件选择测试替身已恢复，临时文件服务器已关闭。

## 充值后复测

- 官方余额接口恢复 `is_available=true`。
- XLSX/PPTX/TXT 组合问答接口 HTTP 200：MAPLE-584102 合计 43；CEDAR-703618、2026-12-08、6400、Iris；BIRCH-826045、58，全部符合样本。
- Web 从文件菜单重新上传三种附件，经发送按钮发起问答，结果全部正确；375×812 截图检查文件名、回答、工具栏正常。
- Android 从系统文件选择器选择三种附件，真实上传后经发送按钮提问，结果全部正确；截图 `/private/tmp/uni-ai-android-extra-doc-answer.png` 检查正常。此前余额导致的三种格式阻塞已解除。

## 新基座与附件交互收尾

- 新自定义基座打包成功，并已覆盖安装到同一安卓设备，原聊天数据保留；系统权限确认包含 RECORD_AUDIO。
- Android TTS 实际播放器启动，用户确认听到声音；系统 AudioTrack 记录同一应用 PID 的 started、stopped、release，手动停止验证通过。
- Android 麦克风授权、录音、停止、上传七牛 ASR、识别回填完成；用手机朗读声作录音样本，输入框出现相应日期/预算等文本，未自动发送。部分英文专名转写有误，未宣称转写准确率保证。
- 参考 DeepSeek 官网实际附件草稿卡片，输入框上方新增文件名、类型、上传进度/解析/就绪/失败重试、逐个移除；多个附件横向滚动。未就绪/失败附件阻止提前发送。发送后清空草稿，文件随消息保留。
- Web 实际上传成功；受控上传验证 45% 进度、503 失败、阻止发送；恢复真实接口后重试成功，移除和发送验证通过。Android 实际选取 XLSX/PPTX，卡片、横向列表、逐个移除、只发送剩余 PPTX 并正确问答，截图通过。
- 全屏按钮移到文字输入区；修正移动 Web 全屏容器宽度偏移，全屏卡片和输入文字可见。
- 新增 3 项上传草稿状态、取消迟到结果、失败重试测试，总计 30 项通过。Web/Android HBuilderX 编译与运行日志检查未见本轮相关异常。

## 2026-11-17：按用户 DeepSeek APP 照片调整交互

- 默认文字输入，右侧语音图标切换“按住说话”，键盘图标切回文字；空草稿不显示发送按钮。
- 加号展开拍照、相册、文件和保留的识字入口，展开后变叉号。照片/相册分别使用 camera/album 来源；文件直接进入系统选择器。附件上传、就绪卡片、失败重试和移除保留；OCR 处理期间入口显示解析中。
- 按住录音后隐藏草稿、编辑提示、工具栏和附件面板；底部白到蓝渐变，只显示“松手发送，上滑取消”和白色长波形。上滑超过 60px 改为红色渐变、红色波形和“松手取消”。
- 松手立即显示“正在识别…”和灰色转圈，识别成功自动发送；短按、系统 touchcancel、授权等待时已松手、切换会话不会误发。附件未就绪时保留转写草稿并提示等待。长录音限制 60 秒。
- 朗读按钮使用扬声器图标；请求/缓冲期间灰色转圈，实际 onPlay 后显示蓝紫色五段交错起伏短线，再点停止。
- Web：真实 TTS 音频作为受控麦克风输入，真实七牛 ASR 识别并自动发送，收到“语音测试成功”；上滑取消不增加消息。截图检查最终蓝色/红色全区域、识别转圈、朗读加载/播放状态；新文件入口真实上传 TXT 并显示就绪卡片。受控路由检查 camera/album 参数正确，测试替身均已恢复。
- Android 192.168.2.3:42999：相机权限及相机拉起、相册选择器、系统文件选择器、TXT 上传与问答通过，内容 BIRCH-826045/58 正确。麦克风录到外放测试音，松手识别并自动发送，收到“语音测试成功”；另一次转写有措辞差异，不保证精确识别率。最终蓝色录音、红色取消、松手识别和取消恢复均截图检查；取消未新增消息。
- Android 朗读灰色加载与实际播放的波形两帧已截图，线段高度不同；AudioTrack 记录实际播放，手动再次点击停止验证完成。
- 修复真机发现的 uni.hideKeyboard 对缺失 uni-keyboard 模块的依赖，改用官方示例的输入框 blur()；不需要为这次交互重打自定义基座。调试期间另遇编译缓存缺失和本地资源下载端口错配，清缓存重编、重新启动同步后恢复，最终 ADB 端口映射已由 HBuilderX 正常重建。
- 新增 6 项语音手势/授权竞态/草稿阻塞测试；与原有回归共 36 项通过。最终 Web/Android HBuilderX lastBuild 日志编译成功，安卓实际同步与启动完成。
- 真机截图：`/private/tmp/uni-ai-native-final-blue.png`、`uni-ai-native-final-red.png`、`uni-ai-native-final-recognizing.png`、`uni-ai-native-final-canceled.png`、`uni-ai-native-speech-loading.png`、`uni-ai-native-speech-frame-4.png`、`uni-ai-native-speech-frame-6.png`、`uni-ai-native-speech-stopped.png`。
